import Link from "next/link";
import { supabase, supabaseConfigured } from "@/lib/supabase";
import { ArrowUpRight, Gamepad2, Smartphone, Sparkles } from "lucide-react";

type Project = {
  id: string; title: string; slug: string; description: string | null;
  cover_url: string | null; project_type: string; category: string | null;
  download_url: string | null; featured: boolean; status: string;
};

const demoProjects: Project[] = [
  { id:"demo-1", title:"Your next game", slug:"your-next-game", description:"Add your first game from the admin panel and it will appear here.", cover_url:null, project_type:"game", category:"Featured", download_url:null, featured:true, status:"published" },
  { id:"demo-2", title:"Your next app", slug:"your-next-app", description:"Showcase your Android apps with screenshots, details, and official download links.", cover_url:null, project_type:"app", category:"Android", download_url:null, featured:false, status:"published" }
];

async function getProjects(): Promise<Project[]> {
  if (!supabaseConfigured || !supabase) return demoProjects;
  const { data, error } = await supabase.from("projects")
    .select("id,title,slug,description,cover_url,project_type,category,download_url,featured,status")
    .eq("status", "published").order("featured", { ascending: false }).order("created_at", { ascending: false });
  if (error || !data?.length) return demoProjects;
  return data as Project[];
}

function Cover({ project }: { project: Project }) {
  return project.cover_url
    ? <div className="cover" style={{ backgroundImage: `linear-gradient(0deg, #090b10cc, transparent 70%), url("${project.cover_url}")` }} />
    : <div className={`cover placeholder ${project.project_type === "app" ? "app-cover" : ""}`}>
        <span className="cover-mark">AAK</span><span className="cover-sub">STUDIO / DIGITAL WORLDS</span>
      </div>;
}

export default async function Home() {
  const projects = await getProjects();
  const featured = projects.find(p => p.featured) ?? projects[0];
  const games = projects.filter(p => p.project_type === "game");
  const apps = projects.filter(p => p.project_type === "app");
  return <main>
    <header className="topbar">
      <Link href="/" className="brand"><span className="brand-icon">A</span><span>AAK <b>STUDIO</b></span></Link>
      <nav><a href="#games">Games</a><a href="#apps">Apps</a><a href="#about">About</a></nav>
      <Link className="admin-link" href="/admin">Studio Admin <ArrowUpRight size={15}/></Link>
    </header>
    <section className="hero">
      <div className="hero-copy">
        <div className="eyebrow"><Sparkles size={14}/> INDEPENDENT DIGITAL STUDIO</div>
        <h1>Ideas become<br/><span>playable worlds.</span></h1>
        <p>Discover games, apps, and experiments built with passion by AAK Studio.</p>
        <div className="hero-actions"><a className="button primary" href="#games"><Gamepad2 size={17}/> Explore games</a><a className="button secondary" href="#apps">Discover apps <ArrowUpRight size={16}/></a></div>
        <div className="hero-note"><span className="status-dot"/> BUILT INDEPENDENTLY. MADE TO BE PLAYED.</div>
      </div>
      <div className="hero-art">
        {featured ? <><Cover project={featured}/><div className="feature-label"><span>FEATURED PROJECT</span><h2>{featured.title}</h2><p>{featured.description || "A new experience from AAK Studio."}</p>{featured.download_url && <a href={featured.download_url} target="_blank" rel="noreferrer">Get the game <ArrowUpRight size={15}/></a>}</div></> :
          <div className="hero-placeholder"><span>AAK</span><small>YOUR NEXT BIG IDEA</small></div>}
        <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
      </div>
    </section>
    <section className="section" id="games">
      <div className="section-heading"><div><div className="eyebrow">PLAY SOMETHING NEW</div><h2>Games <span>& experiences</span></h2></div><span className="count">{games.length.toString().padStart(2,"0")} PROJECTS</span></div>
      <div className="project-grid">{games.length ? games.map(p => <ProjectCard key={p.id} project={p}/>) : <EmptyCard kind="game"/>}</div>
    </section>
    <section className="section apps-section" id="apps">
      <div className="section-heading"><div><div className="eyebrow">TOOLS FOR YOUR EVERYDAY</div><h2>Apps <span>& utilities</span></h2></div><span className="count"><Smartphone size={14}/> {apps.length.toString().padStart(2,"0")} PROJECTS</span></div>
      <div className="project-grid">{apps.length ? apps.map(p => <ProjectCard key={p.id} project={p}/>) : <EmptyCard kind="app"/>}</div>
    </section>
    <section className="about" id="about"><div className="eyebrow">SMALL STUDIO. BIG IDEAS.</div><h2>Made with curiosity.<br/><span>Built for what’s next.</span></h2><p>AAK Studio is an independent home for games, apps, and creative technology projects.</p></section>
    <footer><Link href="/" className="brand"><span className="brand-icon">A</span><span>AAK <b>STUDIO</b></span></Link><span>© {new Date().getFullYear()} AAK Studio. All rights reserved.</span><Link href="/admin">Manage projects ↗</Link></footer>
  </main>;
}

function ProjectCard({ project }: { project: Project }) {
  return <article className="project-card"><Cover project={project}/><div className="card-content"><div className="card-meta"><span>{project.project_type === "game" ? "GAME" : "APPLICATION"}</span><span>{project.category || "AAK ORIGINAL"}</span></div><h3>{project.title}</h3><p>{project.description || "Discover this project from AAK Studio."}</p><a className="card-link" href={project.download_url || `#${project.slug}`} target={project.download_url ? "_blank" : undefined} rel={project.download_url ? "noreferrer" : undefined}>{project.download_url ? "View download" : "Coming soon"} <ArrowUpRight size={15}/></a></div></article>;
}
function EmptyCard({ kind }: { kind: "game" | "app" }) {
  return <div className="empty-card"><span>{kind === "game" ? <Gamepad2/> : <Smartphone/>}</span><h3>Your next {kind === "game" ? "game" : "app"} goes here.</h3><p>Connect Supabase, then add a project through the admin panel.</p><Link href="/admin">Open studio admin <ArrowUpRight size={14}/></Link></div>;
}