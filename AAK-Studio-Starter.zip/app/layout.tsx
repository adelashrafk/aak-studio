import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AAK Studio — Games & Apps",
  description: "Discover games, apps, and digital projects made by AAK Studio.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}