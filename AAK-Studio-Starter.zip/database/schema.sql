-- AAK Studio initial schema. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'AAK Studio Admin',
  role text not null default 'admin' check (role in ('admin','editor')),
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text,
  cover_url text,
  project_type text not null check (project_type in ('game','app')),
  category text,
  version text,
  size_text text,
  platform text,
  download_url text,
  featured boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id integer primary key default 1 check (id = 1),
  site_name text not null default 'AAK Studio',
  tagline text not null default 'Ideas become playable worlds.',
  logo_url text,
  accent_color text not null default '#b7ff5b',
  about_text text not null default 'An independent home for games, apps, and creative technology.',
  updated_at timestamptz not null default now()
);
insert into public.site_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.store_sections (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text,
  project_type text not null default 'mixed' check (project_type in ('game','app','mixed')),
  sort_order integer not null default 0,
  visible boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.site_settings enable row level security;
alter table public.store_sections enable row level security;

-- Public visitors can only read published projects and visible public settings/sections.
create policy "Public can read published projects" on public.projects
  for select using (status = 'published');
create policy "Public can read site settings" on public.site_settings
  for select using (true);
create policy "Public can read visible sections" on public.store_sections
  for select using (visible = true);

-- Only authenticated users explicitly registered in profiles may edit content.
create policy "Admins can read profiles" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "Admins can manage projects" on public.projects
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','editor'))
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','editor'))
  );
create policy "Admins can manage settings" on public.site_settings
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );
create policy "Admins can manage sections" on public.store_sections
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- IMPORTANT: After creating your user in Supabase Authentication, insert its exact UUID below:
-- insert into public.profiles (id, display_name, role) values ('YOUR_AUTH_USER_UUID', 'AAK Studio Admin', 'admin');
-- Never expose a service_role key in frontend code or NEXT_PUBLIC_ variables.

-- Optional: create a public storage bucket for cover art. Review bucket policies before enabling uploads.
-- insert into storage.buckets (id, name, public) values ('project-covers', 'project-covers', true)
-- on conflict (id) do nothing;